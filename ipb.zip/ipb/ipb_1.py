import socket
import struct
import can
from can.interfaces import socketcan
from can import message

# CAN帧结构
class CustomCanFrame:
    def __init__(self, can_id, can_dlc, data):
        self.can_id = can_id
        self.can_dlc = can_dlc
        self.data = data

# 校验和计算
def generate_checksum(frame):
    frame.data[7] = (frame.data[0] + frame.data[1] + frame.data[2] + frame.data[3] + frame.data[4] + frame.data[5] + frame.data[6]) & 0xFF
    return

# 反转位函数
def reverse_bits(counter):
    reversed_counter = 0
    bit_mask = 1
    for i in range(4):
        if counter & bit_mask:
            reversed_counter |= (1 << (3 - i))
        bit_mask <<= 1
    return reversed_counter

# 发送CAN帧
def send_frame_over_can(sock, frame):
    if write(sock, struct.pack('=IB3x8B', frame.can_id, frame.can_dlc) + frame.data) < 0:
        perror("write")
        close(sock)
        return

# 主程序
def main():
    # 创建socket
    sock = socket.socket(socket.PF_CAN, socket.SOCK_RAW, socketcan.CAN_RAW)
    ifr = struct.pack('16sH', b'can1', socket.if_index)
    if ioctl(sock.fileno(), socket.SIOCGIFINDEX, ifr) == -1:
        perror("SIOCGIFINDEX")
        return

    # 绑定socket到CAN接口
    addr = socketcan.make_sockaddr_can(ifr)
    if bind(sock.fileno(), addr, len(addr)) == -1:
        perror("bind")
        return

    # 初始化变量
    TmaxTimeout = False
    flag_control = False
    flag_control_valid = False
    counter = 0

    while True:
        # 读取CAN帧
        frame = socketcan.recv_frame(sock)
        if not frame:
            perror("read")
            break

        # 处理CAN帧
        if frame.can_id == 0x173:
            if frame.data[0] == 0x94:
                print("控制模式开启")
                flag_control_valid = True
            elif frame.data[1] == 0x3F:
                flag_control = True
                print("Handshake has been established!")

        # 发送控制模式
        if flag_control_valid:
            send_frame_over_can(sock, CustomCanFrame(0x13F, 8, [0x9F, 0x11, 0x10, 0xE0, 0x00, 0x37, frame.data[6] & 0x0F | (counters[counter] & 0xF0), 0xD0]))
            print("control 数据报文发送")
        elif flag_control:
            send_frame_over_can(sock, CustomCanFrame(0x13F, 8, [0x9F, 0x01, 0x00, 0xE0, 0x00, 0x07, frame.data[6] & 0x0F | (counters[counter] & 0xF0), 0xD0]))
            flag_control_valid = True
            print("control 模式发送")
        else:
            send_frame_over_can(sock, CustomCanFrame(0x13F, 8, [0x0F, 0x1F, 0x2F, 0x3F, 0x4F,