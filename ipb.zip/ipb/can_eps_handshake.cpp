#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/imu.hpp>
#include <sensor_msgs/msg/nav_sat_fix.hpp>
#include <cstring>
#include <chrono>
#include <iostream>
#include <unistd.h>
#include <sys/socket.h>
#include <linux/can.h>
#include <linux/can/raw.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <chrono>
#include <thread>
using namespace std::chrono_literals;
int reverseBits(int counter) {  
    int reversed = 0;  
    int bitMask = 1; // 从最低位开始  
  
    // 因为counter的范围是0-15，所以我们只需要处理4个位  
    for (int i = 0; i < 4; ++i) {  
        // 检查counter的当前位是否为1  
        if (counter & bitMask) {  
            // 如果是1，则将其设置到reversed的相应高位上  
            reversed |= (1 << (3 - i));  
        }  
        // 移动到下一个位  
        bitMask <<= 1;  
    }  
  
    return reversed;  
}
class EPSClass: public rclcpp::Node
{
  public:
    EPSClass()
      : Node("can_EPS_handshake")
    {
      this->declare_parameter("angle", angle);
      if_APA_active = false;
    }
    void respond()
    {
        this->get_parameter("angle", angle);
        //   RCLCPP_INFO(this->get_logger(), "Hello %s", parameter_string_.c_str());

        int sock = socket(PF_CAN, SOCK_RAW, CAN_RAW);
        if (sock < 0) {
            perror("Socket");
            return;
        }

        struct ifreq ifr;
        strcpy(ifr.ifr_name, "can1");
        ioctl(sock, SIOCGIFINDEX, &ifr);

        struct sockaddr_can addr;
        memset(&addr, 0, sizeof(addr));
        addr.can_family = AF_CAN;
        addr.can_ifindex = ifr.ifr_ifindex;

        if (bind(sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
            perror("Bind");
            return;
        }
        while(1){
            struct can_frame frame;
            int nbytes = read(sock, &frame, sizeof(struct can_frame));
            if (nbytes < 0) {
                perror("Read");
                break;
            }
            switch (frame.can_id) {
                case 0x135: {
                    if ((frame.data[4] & 0xC0 == 0x40  && frame.data[5] & 0x01 == 0x0 || frame.data[4] & 0xC0 == 0x0 && frame.data[5] & 0x01 == 0x01) ) {
                        if_APA_active = true;
                    }
                    
                    // printf("Got 0x135 CAN message\n");
                    // printf("angle =%d\n", angle);
                    // int64_t bytes;
                    // memcpy(&bytes, frame.data, sizeof(int8_t));
                    // EPS_APA_CtrlStas = (bytes >> 12) & 0x7;
                    // printf("EPS_APA_CtrlStas = %d\n", EPS_APA_CtrlStas);
                    // if (EPS_APA_CtrlStas != 0x01 && EPS_APA_CtrlStas != 0x02) {
                    //     send_to_ipb(sock);
                    //     counter++;
                    //     break;
                    // } else {
                    //     if (EPS_APA_CtrlStas == 0x01) {
                    //         printf("Handshake has been established!, angle =%d\n", angle);
                    //     }
                            
                    //     APA_Auto_Parking_Status_S = 0X2;
                    //     APA_SteeringCtrlReqForEPS_S = 0x1;
                    //     APA_Target_Steering_Angle = 0x1e77;
                    //     send_to_ipb(sock);
                    //     counter++;
                    // }
                    ;
                }
                if (if_APA_active) {
                        send_angle_to_eps(sock);
                        printf("send_angle_to_eps\n");
                        }
                    else 
                    {
                        send_to_eps(sock);
                        printf("send_to_eps\n");
                        if_APA_active = true;
                    }
                                        // send_to_eps(sock);
                        // counter++;
            }
            // std::this_thread::sleep_for(std::chrono::milliseconds(20));
        }
        // 关闭socket
        close(sock);
    }
  private:
    std::string parameter_string_;
    rclcpp::TimerBase::SharedPtr timer_;
    static bool TmaxTimeout;
    unsigned char EPS_APA_CtrlStas = 0x0;
    unsigned char APA_SteeringCtrlReqForEPS_S = 0x0;
    unsigned char APA_Auto_Parking_Status_S = 0x0;
    int16_t APA_Target_Steering_Angle = 0;
    unsigned char APA_SteeringCtrlReqForEPSVD_S = 1;
    int16_t angle = 0, current_angle = 0;
    unsigned char counter = 0;
    bool if_APA_active;
    void generate_checksum(struct can_frame& frame) {
        frame.data[7] = (frame.data[0] + frame.data[1] + frame.data[2] + frame.data[3] + frame.data[4] + frame.data[5] + frame.data[6]) xor 0xFF;
        // printf("%u + \n%u + \n%u + \n%u + \n%u + \n%u + \n%u + \n= %u\n", frame.data[0], frame.data[1], frame.data[2], frame.data[3], 
        // frame.data[4], frame.data[5], frame.data[6], frame.data[7]);
        return;
    }
    void changeTimeFLag() {
        TmaxTimeout = true;
    }
    void send_to_ipb(int s) {
        // 准备CAN帧
        struct can_frame frame;
        frame.can_id = 0x134; // CAN标识符
        frame.can_dlc = 8;    // 数据长度
        frame.data[0] = 0x0; // 
        frame.data[0] |= (APA_Auto_Parking_Status_S << 5);//APA_Auto_Parking_Status_S
        frame.data[1] = 0x0; // 
        frame.data[1] |= (APA_SteeringCtrlReqForEPS_S << 4); //
        frame.data[1] |= (APA_SteeringCtrlReqForEPSVD_S << 3);
        frame.data[2] = 0;
        frame.data[2] |= ((unsigned char)(APA_Target_Steering_Angle >> 8));
        frame.data[3] = 0;
        frame.data[3] |= ((unsigned char)(APA_Target_Steering_Angle & 0xff));
        frame.data[4] = 0;
        frame.data[5] = 0x0;
        frame.data[6] = 0x0;//初始车速、计数器为0
        frame.data[6] |= (counter);
        
        generate_checksum(frame);
        // 发送CAN帧
        if (write(s, &frame, sizeof(frame)) < 0) {
            perror("write");
            close(s);
            return ;
        }
        counter++;
        printf("[%d]CAN帧已发送\n", counter);
    }
    void send_to_eps(int s) {
        // 准备CAN帧
        struct can_frame frame;
        frame.can_id = 0x134; // CAN标识符
        frame.can_dlc = 8;    // 数据长度
        // frame.data[0] = 0x0; // 
        // frame.data[0] |= (APA_Auto_Parking_Status_S << 5);//APA_Auto_Parking_Status_S
        // frame.data[1] = 0x0; // 
        // frame.data[1] |= (APA_SteeringCtrlReqForEPS_S << 4); //
        // frame.data[1] |= (APA_SteeringCtrlReqForEPSVD_S << 3);
        // frame.data[2] = 0;
        // frame.data[2] |= ((unsigned char)(APA_Target_Steering_Angle >> 8));
        // frame.data[3] = 0;
        // frame.data[3] |= ((unsigned char)(APA_Target_Steering_Angle & 0xff));
        // frame.data[4] = 0;
        // frame.data[5] = 0x0;
        // frame.data[6] = 0x0;//初始车速、计数器为0
        // frame.data[6] |= (counter);
        frame.data[0] = 0xF9;
        frame.data[1] = 0x97;
        frame.data[2] = 0x3C;
        frame.data[3] = 0xF0;
        frame.data[4] = 0xFF;
        frame.data[5] = 0xFF;
        frame.data[6] = 0X00;
        frame.data[6] = frame.data[6] | (counter << 4);
        generate_checksum(frame);
        // 发送CAN帧
        if (write(s, &frame, sizeof(frame)) < 0) {
            perror("write");
            close(s);
            return ;
        }
        counter++;
        if(counter == 16) counter = 0;
        printf("[%d]CAN帧已发送\n", counter);
    }
    void send_mode_to_eps(int s) {
        // 准备CAN帧
        struct can_frame frame;
        frame.can_id = 0x134; // CAN标识符
        frame.can_dlc = 8;    // 数据长度
        // frame.data[0] = 0x0; // 
        // frame.data[0] |= (APA_Auto_Parking_Status_S << 5);//APA_Auto_Parking_Status_S
        // frame.data[1] = 0x0; // 
        // frame.data[1] |= (APA_SteeringCtrlReqForEPS_S << 4); //
        // frame.data[1] |= (APA_SteeringCtrlReqForEPSVD_S << 3);
        // frame.data[2] = 0;
        // frame.data[2] |= ((unsigned char)(APA_Target_Steering_Angle >> 8));
        // frame.data[3] = 0;
        // frame.data[3] |= ((unsigned char)(APA_Target_Steering_Angle & 0xff));
        // frame.data[4] = 0;
        // frame.data[5] = 0x0;
        // frame.data[6] = 0x0;//初始车速、计数器为0
        // frame.data[6] |= (counter);
        frame.data[0] = 0xFA;
        frame.data[1] = 0x9F;
        frame.data[2] = 0x3C;
        frame.data[3] = 0xF0;
        frame.data[4] = 0xFF;
        frame.data[5] = 0xFF;
        // frame.data[6] = 0X00;
        frame.data[6] = 0x04;
        frame.data[6] = frame.data[6] | (counter << 4);
        generate_checksum(frame);
        // 发送CAN帧
        if (write(s, &frame, sizeof(frame)) < 0) {
            perror("write");
            close(s);
            return ;
        }
        counter++;
        if(counter == 16) counter = 0;
        printf("[%d]CAN帧已发送\n", counter);
    }
    
    void send_angle_to_eps(int s) {
        // 准备CAN帧
        struct can_frame frame;
        frame.can_id = 0x134; // CAN标识符
        frame.can_dlc = 8;    // 数据长度

        frame.data[0] = 0xFA;
        frame.data[1] = 0x9F;
        frame.data[2] = 0x3C;
        frame.data[3] = 0xF0;
        frame.data[4] = 0xFF;
        frame.data[5] = 0xFF;
        // frame.data[6] = 0X00;
        frame.data[6] = 0x04;
        frame.data[6] = frame.data[6] | (counter << 4);
        generate_checksum(frame);
        // 发送CAN帧
        if (write(s, &frame, sizeof(frame)) < 0) {
            perror("write");
            close(s);
            return ;
        }
        counter++;
        if(counter == 16) counter = 0;
        printf("[%d]CAN帧已发送\n", counter);
    }
};

bool EPSClass::TmaxTimeout = false;
int main(int argc, char *argv[]) {
    rclcpp::init(argc, argv);
    auto node = rclcpp::Node::make_shared("can_EPS_handshake");
    // rclcpp::spin(std::make_shared<EPSClass>());
    auto eps = std::make_shared<EPSClass>();
    eps->respond();
    rclcpp::shutdown();
    return 0;

    
}

