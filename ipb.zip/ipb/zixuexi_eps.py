# import can

# # 创建CAN接口
# bus = can.interface.Bus(bustype='socketcan', channel='can1', bitrate=500000)

# # 定义一个计数器
# counter = 0

# # 定义0x134的初始数据
# data_134 = [0x00] * 8

# # 定义是否跳过当前帧
# skip_frame = False

# # 定义上次0x134数据的第2、3字节
# last_data_134_2_3 = [0x00, 0x00]

# def calculate_checksum(data):
#     checksum = 0
    
#     for byte in data[:7]:
#         checksum += byte
#     checksum = checksum & 0xFF
#     return checksum ^ 0xFF

# angle_11f_1 = 0
# angle_11f_2 = 0
# while True:
#     # print("M")
#     message = bus.recv()
#     # print("F")
#     if message.arbitration_id == 0x11F:
#         # print("11F")
#     # 读取0x11F报文数据的前两个字节内容
#         angle_11f_1 = message.data[0]
#         angle_11f_2 = message.data[1]
#         continue
#     if message.arbitration_id == 0x135:
#         # print("135")
#         # 读取0x135的4.6, 4.7和5.0三个位
#         bit_4_6 = (message.data[4] & 0x40) >> 6
#         bit_4_7 = (message.data[4] & 0x80) >> 7
#         bit_5_0 = (message.data[5] & 0x01)
       
#         if bit_4_6 == 0 and bit_4_7 == 0 and bit_5_0 == 0:
#             print("1")
#             skip_frame = False
#             data_134[1] &= ~(1 << 3)  # 0x134的1.3位写为0
            
#             data_134[2] = angle_11f_1
#             data_134[3] = angle_11f_2
#         elif bit_4_6 == 0 and bit_4_7 == 0 and bit_5_0 == 1:
#             skip_frame = True
#             print("2")
#         elif bit_4_6 == 0 and bit_4_7 == 1 and bit_5_0 == 0:
#             print("3")
#             data_134[2] = (last_data_134_2_3[0]) & 0xFF
#             data_134[3] = (last_data_134_2_3[1] + 30) & 0xFF
#             last_data_134_2_3 = [data_134[2], data_134[3]]
   
#     if not skip_frame:
#         # 更新0x134报文的counter
#         data_134[6] = (counter << 4) & 0xF0
#         counter = (counter + 1) % 16

#         data_134[0] = 0xF2
#         data_134[1] = data_134[1] | 0x10
#         data_134[6] = data_134[6] | 0x04
#         # 计算校验字节
#         data_134[7] = calculate_checksum(data_134)
       
#         # 发送0x134报文
#         msg_134 = can.Message(arbitration_id=0x134, data=data_134, is_extended_id=False)
#         bus.send(msg_134)

import can
import time
from time import time as tm
# 创建CAN接口
bus = can.interface.Bus(bustype='socketcan', channel='can1', bitrate=500000)

# 定义一个计数器
counter = 0

# 定义0x134的初始数据
data_134 = [0x00] * 8

# 定义是否跳过当前帧
skip_frame = False

# 定义上次0x134数据的第2、3字节
last_data_134_2_3 = [0x00, 0x00]

def calculate_checksum(data):
    checksum = 0
    
    for byte in data[:7]:
        checksum += byte
    checksum = checksum & 0xFF
    return checksum ^ 0xFF

angle_11f_1 = 0
angle_11f_2 = 0
while True:
    # print("M")
    # message = bus.recv()
    
    # if message.arbitration_id == 0x135:
        # print("135")
        # 读取0x135的4.6, 4.7和5.0三个位
    # bit_4_6 = (message.data[4] & 0x40) >> 6
    # bit_4_7 = (message.data[4] & 0x80) >> 7
    # bit_5_0 = (message.data[5] & 0x01)
    data_134[1] |= (1 << 3)
    # if bit_4_6 == 0 and bit_4_7 == 0 and bit_5_0 == 0:
    #     print("1")
    skip_frame = False
        # 0x134的1.3位写为0
    
    data_134[2] = 0x1E
    data_134[3] = 0x78
    data_134[0] = 0xF9
    data_134[1] = 0x97
    data_134[2] = 0xE4
    data_134[3] = 0x1D
    data_134[4] = 0xFF
    data_134[5] = 0xFF
        
    # elif bit_4_6 == 0 and bit_4_7 == 0 and bit_5_0 == 1 or bit_4_6 == 0 and bit_4_7 == 1 and bit_5_0 == 0:
    # else:
    #     data_134[0] = 0xFA
    #     data_134[1] = 0x9F
    #     data_134[2] = 0x7E
    #     data_134[3] = 0x1E
    #     data_134[4] = 0xFF
    #     data_134[5] = 0xFF
    #     # data_134[2] = (last_data_134_2_3[0]) & 0xFF
    #     # data_134[3] = (last_data_134_2_3[1] + 30) & 0xFF
    #     last_data_134_2_3 = [data_134[2], data_134[3]]
    print("2")

    
    # 更新0x134报文的counter
    data_134[6] = (counter << 4) & 0xF0
    counter = (counter + 1) % 16

    # data_134[0] = 0xF2
    # data_134[1] = data_134[1] | 0x10
    data_134[6] = data_134[6] | 0x04
    # 计算校验字节
    
    data_134[7] = calculate_checksum(data_134)

    # 发送0x134报文
    msg_134 = can.Message(arbitration_id=0x134, data=data_134, is_extended_id=False)
    bus.send(msg_134)
    time.sleep(0.0195)