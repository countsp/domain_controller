import socket
import struct
import time
import can
bus = can.interface.Bus(bustype='socketcan', channel='can1', bitrate=500000)
# 位反转函数
def reverse_bits(counter):
    reversed = 0
    bit_mask = 1
    for i in range(4):
        if counter & bit_mask:
            reversed |= (1 << (3 - i))
        bit_mask <<= 1
    return reversed

class IPBClass:
    def __init__(self):
        self.flag_control = False
        self.flag_control_valid = False
        self.counter = 0
        self.counters = [0x0F, 0x1F, 0x2F, 0x3F, 0x4F, 0x5F, 0x6F, 0x7F, 0x8F, 0x9F, 0xAF, 0xBF, 0xCF, 0xDF, 0xEF, 0xFF]
        
    def generate_checksum(self, frame):
        frame[7] = (frame[0] + frame[1] + frame[2] + frame[3] + frame[4] + frame[5] + frame[6]) ^ 0xFF
        frame[7] &= 0xFF

    def send_to_ipb(self, sock):
        frame = [0]*8
        frame[0] = 0x1F
        frame[1] = 0x00
        frame[2] = 0x00
        frame[3] = 0xE0
        frame[4] = 0x00
        frame[5] = 0x03
        frame[6] = (self.counters[self.counter] & 0xF0) | (frame[6] & 0x0F)
        frame[7] = 0xD0
        self.generate_checksum(frame)
        print(0xD0)
        can_frame = struct.pack("B"*8, *frame)
        sock.send(can_frame)
        self.counter = (self.counter + 1) % 16

    def send_control_mode_to_ipb(self, sock):
        frame = [0]*8
        frame[0] = 0x9F
        frame[1] = 0x01
        frame[2] = 0x00
        frame[3] = 0xE0
        frame[4] = 0x00
        frame[5] = 0x07
        frame[6] = (self.counters[self.counter] & 0xF0) | (frame[6] & 0x0F)
        frame[7] = 0xD0
        self.generate_checksum(frame)
        can_frame = struct.pack("B"*8, *frame)
        sock.send(can_frame)
        self.counter = (self.counter + 1) % 16

    def send_control_cmd_to_ipb(self, sock):
        frame = [0]*8
        frame[0] = 0x9F
        frame[1] = 0x11  # 21:BACK 11:FORWARD
        frame[2] = 0x10
        frame[3] = 0xE0
        frame[4] = 0x00
        frame[5] = 0x37
        frame[6] = (self.counters[self.counter] & 0xF0) | (frame[6] & 0x0F)
        frame[7] = 0xD0
        self.generate_checksum(frame)
        can_frame = struct.pack("B"*8, *frame)
        sock.send(can_frame)
        self.counter = (self.counter + 1) % 16

    def respond(self):
        # sock = socket.socket(socket.AF_CAN, socket.SOCK_RAW, socket.CAN_RAW)
        # sock.bind(('can1',))

        while True:
            frame = bus.recv(12)
            if not frame:
                break
            can_id, data = struct.unpack("I8s", frame)
            if can_id == 0x173:
                if data[0] == 0x94:
                    self.flag_control_valid = True
                    print("控制模式开启")
                if data[1] == 0x3F:
                    self.flag_control = True
                    print("Handshake has been established!")

            if self.flag_control_valid:
                self.send_control_cmd_to_ipb(sock)
                print("control 数据报文发送")
            elif self.flag_control:
                self.send_control_mode_to_ipb(sock)
                self.flag_control_valid = True
                print("control 模式发送")
            else:
                self.send_to_ipb(sock)
                print("握手报文发送")

        sock.close()

if __name__ == "__main__":
    ipb = IPBClass()
    ipb.respond()