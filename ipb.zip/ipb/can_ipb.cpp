#include <cstring>
#include <chrono>
#include <iostream>
#include <unistd.h>
#include <sys/socket.h>
#include <linux/can.h>
#include <linux/can/raw.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <chrono>
#include <thread>
using namespace std::chrono_literals;

#include <iostream>  
#include <bitset> // 用于打印二进制表示  
std::string parameter_string_;
static bool TmaxTimeout;
bool flag_control, flag_control_valid;
unsigned char APA_LSMVehSecReq_S = 0x0;
int16_t APA_LSMDistToStop_S = 1;
unsigned char APA_LSMVehDirRq_S = 0x01;//0x1:前进，0x2:后退 
int APA_LSMvMaxRq_S = 0x0;
unsigned char speed = 0;
int counter = 0;//报文序号

unsigned char counters[16] = {0x0F, 0x1F, 0x2F, 0x3F, 0x4F, 0x5F, 0x6F, 0x7F, 0x8F, 0x9F, 0xAF, 0xBF, 0xCF, 0xDF, 0xEF, 0xFF}; 

void generate_checksum(struct can_frame& frame) {
    //校验位计算
    frame.data[7] = (frame.data[0] + frame.data[1] + frame.data[2] + frame.data[3] + frame.data[4] + frame.data[5] + frame.data[6]) xor 0xFF;
    return;
}
void static changeTimeFLag() {
    TmaxTimeout = true;
}
void send_to_ipb(int s) {
    // 准备CAN帧
    struct can_frame frame;
    frame.can_id = 0x13F; // CAN标识符
    frame.can_dlc = 8;    // 数据长度
    
    frame.data[0] = 0x1F;
    frame.data[1] = 0x00;
    frame.data[2] = 0x00;
    frame.data[3] = 0xE0;
    frame.data[4] = 0x00;
    frame.data[5] = 0x03;
    // frame.data[6] = (reverseBits(counter) << 4);
    frame.data[6] = frame.data[6] & 0x0F;
    frame.data[6] = frame.data[6] | (counters[counter] & 0xF0);
    frame.data[7] = 0xD0;
    // frame.data[6] |= ((counter / 3) & 0xf);
    std::cout << counter << " vs " << int(frame.data[6]) << std::endl;
    generate_checksum(frame);
    // 发送CAN帧
    if (write(s, &frame, sizeof(frame)) < 0) {
        perror("write");
        close(s);
        return ;
    }
    counter++;
    if(counter == 16) counter = 0;
}
void send_control_mode_to_ipb(int s) {
    // 准备CAN帧
    struct can_frame frame;
    frame.can_id = 0x13F; // CAN标识符
    frame.can_dlc = 8;    // 数据长度
    frame.data[0] = 0x9F;
    frame.data[1] = 0x01;
    frame.data[2] = 0x00;
    frame.data[3] = 0xE0;
    frame.data[4] = 0x00;
    frame.data[5] = 0x07;
    // frame.data[6] = (reverseBits(counter) << 4);
    frame.data[6] = frame.data[6] & 0x0F;
    frame.data[6] = frame.data[6] | (counters[counter] & 0xF0);
    frame.data[7] = 0xD0;
    // frame.data[6] |= ((counter / 3) & 0xf);

    generate_checksum(frame);
    // 发送CAN帧
    if (write(s, &frame, sizeof(frame)) < 0) {
        perror("write");
        close(s);
        return ;
    }
    counter++;
    if(counter == 16) counter = 0;
    // printf("[%d]CAN帧已发送:%d\n", counter, frame.data[6]);
}
void send_control_cmd_to_ipb(int s) {
        // 准备CAN帧
        struct can_frame frame;
        frame.can_id = 0x13F; // CAN标识符
        frame.can_dlc = 8;    // 数据长度
        frame.data[0] = 0x9F;
        frame.data[1] = 0x11;//21:BACK 11:FORWARD
        frame.data[2] = 0x10;
        frame.data[3] = 0xE0;
        frame.data[4] = 0x00;
        frame.data[5] = 0x37;
        frame.data[6] = frame.data[6] & 0x0F;
        frame.data[6] = frame.data[6] | (counters[counter] & 0xF0);
        frame.data[7] = 0xD0;

        generate_checksum(frame);
        // 发送CAN帧
        if (write(s, &frame, sizeof(frame)) < 0) {
            perror("write");
            close(s);
            return ;
        }
        counter++;
        if(counter == 16) counter = 0;
}

int reverseBits(int counter) {  
    int reversed = 0;  
    int bitMask = 1; // 从最低位开始  
  
    // 因为counter的范围是0-15，所以我们只需要处理4个位  
    for (int i = 0; i < 4; ++i) {  
        // 检查counter的当前位是否为1  
        if (counter & bitMask) {  
            // 如果是1，则将其设置到reversed的相应高位上  
            reversed |= (1 << (3 - i));  
        }  
        // 移动到下一个位  
        bitMask <<= 1;  
    }  
    // printf("------%d vs %d --------\n", counter, reversed);
    return reversed;  
}  
  
void respond()
{
    //   RCLCPP_INFO(this->get_logger(), "Hello %s", parameter_string_.c_str());
    int sock = socket(PF_CAN, SOCK_RAW, CAN_RAW);
    TmaxTimeout = false;
    if (sock < 0) {
        perror("Socket");
        return;
    }

    struct ifreq ifr;
    strcpy(ifr.ifr_name, "can1");
    ioctl(sock, SIOCGIFINDEX, &ifr);

    struct sockaddr_can addr;
    memset(&addr, 0, sizeof(addr));
    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;

    if (bind(sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("Bind");
        return;
    }
    flag_control = false;
    flag_control_valid = false;
    // timer = this->create_wall_timer(20ms, changeTimeFLag);

    while(1){
        struct can_frame frame;
        int nbytes = read(sock, &frame, sizeof(struct can_frame));
        if (nbytes < 0) {
            perror("Read");
            break;
        }

        switch (frame.can_id) {
            case 0x173: {
                // printf("Got 0x173 CAN message\n");
                int8_t byte;
                memcpy(&byte, frame.data, 2*sizeof(int8_t));
                printf("data 1: %u\n", frame.data[0]);
                // if ((byte>>8) & 0x3 != 0 || (byte) & 0x0F != 0x0) {
                if (frame.data[0] == 0x94) {
                    printf("控制模式开启\n");
                    flag_control_valid = true;
                    break;
                }
                if (frame.data[1] != 0x3F) {
                    // printf("\n");
                    break;
                } else {
                    flag_control = true;
                    printf("Handshake has been established!\n");

                }
                break;
            }
        }
        if (flag_control_valid) 
        {
            send_control_cmd_to_ipb(sock);
            printf("control 数据报文发送\n");
        }
        else if (flag_control) 
        {
            send_control_mode_to_ipb(sock);
            flag_control_valid = true;
            printf("control 模式发送\n");
        }
        else 
        {
            send_to_ipb(sock);
            printf("握手报文发送\n");
        }
    }
    // 关闭socket
    close(sock);
}


int main(int argc, char *argv[]) {

    respond();
    return 0;
    
}

