import can
import time

# 初始化CAN接口
can_interface = 'can1'  # 根据实际情况修改
bus = can.interface.Bus(channel=can_interface, bustype='socketcan')

# 定义CAN报文
message1 = can.Message(arbitration_id=0x13F, data=[0x1f, 0x00, 0x00, 0x10, 0x00, 0x03], is_extended_id=False)
message2 = can.Message(arbitration_id=0x9F0, data=[0x1f, 0x01, 0x00, 0xe0, 0x00, 0x07], is_extended_id=False)
message3 = can.Message(arbitration_id=0x9F1, data=[0x1f, 0x11, 0x10, 0xe0, 0x00, 0x37], is_extended_id=False)

try:
    while True:
        # 发送第一个报文
        bus.send(message1)
        time.sleep(0.02)  # 等待20ms

        # 发送第二个报文
        bus.send(message2)
        time.sleep(0.02)  # 等待20ms

        # 发送第三个报文
        bus.send(message3)
        time.sleep(0.02)  # 等待20ms

except KeyboardInterrupt:
    print("用户中断，程序退出")

except can.CanError as e:
    print(f"CAN错误: {e}")

finally:
    bus.shutdown()
